package library;

public class Cdrom {

	private String code;
	private String titulo;
	private String autor;
	private String material;
	private String editorial;
	private boolean alquilado;
	private Usuario user;
	private String fecha_ini;
	private String fecha_fin; 
	
	/*
	 * boolean alquila (usuario u, String f_inicio, String f_final)
	 * 
	 */
	
	Cdrom (){
		
	}
	
	Cdrom (String code, String titulo, String autor, String material, String editorial){
		
		this.code = code;
		this.titulo = titulo;
		this.autor = autor;
		this.material = material;
		this.editorial = editorial;
		
	}

	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public boolean getAlquilado() {
		return alquilado;
	}
	private void setAlquilado(boolean alquilado) {
		this.alquilado = alquilado;
	}

	public Usuario getUser() {
		return user;
	}

	public void setUser(Usuario user) {
		this.user = user;
	}

	public String getFecha_ini() {
		return fecha_ini;
	}

	public void setFecha_ini(String fecha_ini) {
		this.fecha_ini = fecha_ini;
	}

	public String getFecha_fin() {
		return fecha_fin;
	}

	public void setFecha_fin(String fecha_fin) {
		this.fecha_fin = fecha_fin;
	}

	public boolean alquila (Usuario user, String fecha_ini, String fecha_fin) {
		setAlquilado(true);
		setUser(user);
		setFecha_ini(fecha_ini);
		setFecha_fin(fecha_fin);
	}
	
	public boolean devuelve (Usuario user, String fecha_ini, String fecha_fin) {
		setAlquilado(false);
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public String toString() {
		return "Cdrom [" + (code != null ? "code=" + code + ", " : "")
				+ (titulo != null ? "titulo=" + titulo + ", " : "") + (autor != null ? "autor=" + autor + ", " : "")
				+ (material != null ? "material=" + material + ", " : "")
				+ (editorial != null ? "editorial=" + editorial + ", " : "") + "alquilado=" + alquilado + ", "
				+ (fecha_ini != null ? "fecha_ini=" + fecha_ini + ", " : "")
				+ (fecha_fin != null ? "fecha_fin=" + fecha_fin : "") + "]";
	}

	
	
}

